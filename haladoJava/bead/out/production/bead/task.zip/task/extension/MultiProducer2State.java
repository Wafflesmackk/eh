package task.extension;
public enum MultiProducer2State {
    KEEP, EXTEND,
}
