package task.test;

import org.junit.jupiter.api.Test;
import task.compulsory.MultiProducer.MultiProducerFactory;

import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MultiProducerTest {

    public static int[] value123A = {0};
    public static int[] value123B = {0};

    public static String[] txtA  = {""};
    public static String[] txtB  = {""};


    public static IntSupplier amountLambda123A = () -> ++value123A[0];
    public static IntSupplier amountLambda123B = () -> ++value123B[0];

    public static Supplier<String> contentLambdaA = () -> {
        txtA[0] = txtA[0].concat("a");
        return txtA[0];
    };
    public static Supplier<String> contentLambdaB  = () -> {
        txtB[0] = txtB[0].concat("a");
        return txtB[0];
    };

    @Test
    public void test(){
        BiFunction<IntSupplier,Supplier<String>,String> multiFactA = MultiProducerFactory.provider().get();
        BiFunction<IntSupplier,Supplier<String>,String> multiFactB = MultiProducerFactory.provider().get();

        ArrayList<String> multiFactAOuts  = new ArrayList<>();
        ArrayList<String> multiFactBOuts  = new ArrayList<>();

        List<String> failedAssertions = new ArrayList<>();

        Function<Integer,String> valueCalc = (index) ->{
            StringBuilder value = new StringBuilder();
            return value.append("a".repeat(Math.max(0, index))).toString();
        };

        for(int i = 0; i < 7; i++) {

            String expectedValue = valueCalc.apply(i + 1);



            if(!Objects.equals(txtA[0], txtB[0])){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", txtA[0], txtB[0]));
            }
            multiFactA.apply(amountLambda123A, contentLambdaA);

            if(!Objects.equals(txtA[0], expectedValue)){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", expectedValue, txtA[0]));
            }

            if(!Objects.equals(txtA[0], txtB[0] + "a")){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", txtA[0], txtB[0] + "a"));
            }

            multiFactB.apply(amountLambda123B, contentLambdaB);

            if(!Objects.equals(txtB[0], expectedValue)){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", expectedValue, txtB[0]));
            }

            if(!Objects.equals(txtA[0], txtB[0])){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", txtA[0], txtB[0]));
            }
        }

        assertTrue(failedAssertions.isEmpty(), "Failed assertions: " + String.join("\n ", failedAssertions));
    }


}
