package task.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import task.extension.MultiProducer2.cachedMultiProducer;
import task.extension.MultiProducer2State;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class multiProducerTest2 {

    Supplier<MultiProducer2State> bunchDecisionLambda;
    Supplier<MultiProducer2State> flipDecisionLambda;


    @BeforeEach
    public void setup(){
        final boolean[] flip = {true};
        final int[] count = {0,0};

         flipDecisionLambda = () -> {
            if (flip[0]){
                flip[0] = false;
                return MultiProducer2State.EXTEND;
            }
            else{
                flip[0] = true;
                return  MultiProducer2State.KEEP;
            }
        };

        bunchDecisionLambda = () ->{
            if(count[1] == 0){
                count[0]++;
                count[1] = count[0];
                return MultiProducer2State.EXTEND;
            }
            else{
                count[1]--;
                return MultiProducer2State.KEEP;
            }
        };
    }

    @ParameterizedTest
    @CsvSource(textBlock = """
            "a", 5, 5
            "", 9, 11
            "aaa", 2, 22
    """)
    public void testConstant(String appendTxt, int decisionCount, int checkNum){
            Supplier<MultiProducer2State> constantDecisionLambda = () -> {
                return MultiProducer2State.KEEP;
            };

            String  result = "";

        for (int i = 0; i < checkNum; i++) {
            result = cachedMultiProducer.provider(decisionCount,constantDecisionLambda).get().apply(appendTxt).get();
        }

       assertEquals("",result);
    }

    @Test
    public void flip20(){
        StringBuilder expResult = new StringBuilder();
        String appendTxt = "a";

        Supplier<String> innerLambda = cachedMultiProducer.provider(10,flipDecisionLambda).get().apply(appendTxt);

        List<String> failedAssertions = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            MultiProducer2State decision = (i % 2 == 1) ? MultiProducer2State.EXTEND : MultiProducer2State.KEEP;
            if(decision == MultiProducer2State.EXTEND ){
                expResult.append(appendTxt);
            }
            String result = innerLambda.get();

            if(!expResult.toString().equals(result)){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", expResult, result));
            }
        }

        assertTrue(failedAssertions.isEmpty(), "Failed assertions: " + String.join("\n", failedAssertions));
    }

    @Test
    public void bunch20(){
        StringBuilder expResult = new StringBuilder();
        String appendTxt = "a";
        Supplier<String> innerLambda = cachedMultiProducer.provider(10,bunchDecisionLambda).get().apply(appendTxt);

        List<String> failedAssertions = new ArrayList<>();
        int[] count2 = {0,0};
        Supplier<MultiProducer2State>  bunchDecisionLambda2 = () ->{
            if(count2[1] == 0){
                count2[0]++;
                count2[1] = count2[0];
                return MultiProducer2State.EXTEND;
            }
            else{
                count2[1]--;
                return MultiProducer2State.KEEP;
            }
        };


        for (int i = 0; i < 20; i++) {
            MultiProducer2State decision = bunchDecisionLambda2.get();

            String result = innerLambda.get();
            //System.out.println("exp " + expResult +" ->"+ decision);
            //System.out.println("res " + result +" ->"+ decision);

            if(!expResult.toString().equals(result)){
                failedAssertions.add(String.format("Expected: %s, Actual: %s", expResult, result));
            }
            if(decision == MultiProducer2State.EXTEND){
                expResult.append(appendTxt);
            }
        }

        assertTrue(failedAssertions.isEmpty(), "Failed assertions: " + String.join("\n", failedAssertions));
    }

    @Test
    public void oneOfAB(){
        Supplier<String> onlyA = () -> "a";
        Supplier<String> onlyB = () -> "b";

        BiFunction<Supplier<String>,Supplier<String>,Supplier<String>> oneOfABLambda = cachedMultiProducer.oneForEach();
        Stream<String> resultStream = Stream.generate(oneOfABLambda.apply(onlyA,onlyB)).limit(6);
        List<String> resultList = resultStream.toList();


        assertEquals("a", resultList.get(0));
        assertEquals("b", resultList.get(1));
        assertEquals("a", resultList.get(2));
        assertEquals("b", resultList.get(3));
        assertEquals("a", resultList.get(4));
        assertEquals("b", resultList.get(5));
    }

    @ParameterizedTest
    @CsvSource(textBlock = """
            1
            3
            10
    """)
    public void cachedMultiProducerTest(int decisionCount){
       Supplier<String> flipLambda = cachedMultiProducer.provider(decisionCount,flipDecisionLambda).get().apply("a");
       Supplier<String> bunchLambda = cachedMultiProducer.provider(decisionCount,bunchDecisionLambda).get().apply("b");

        BiFunction<Supplier<String>,Supplier<String>,Supplier<String>> oneOfABLambda = cachedMultiProducer.oneForEach();

       List<String> result  = Stream.generate(oneOfABLambda.apply(flipLambda,bunchLambda)).limit(40).toList();

        List<String> expectedOutput = List.of(new String[]{
                "", "",
                "a", "b",
                "a", "b",
                "aa", "bb",
                "aa", "bb",
                "aaa", "bb",
                "aaa", "bbb",
                "aaaa", "bbb",
                "aaaa", "bbb",
                "aaaaa", "bbb",
                "aaaaa", "bbbb",
                "aaaaaa", "bbbb",
                "aaaaaa", "bbbb",
                "aaaaaaa", "bbbb",
                "aaaaaaa", "bbbb",
                "aaaaaaaa", "bbbbb",
                "aaaaaaaa", "bbbbb",
                "aaaaaaaaa", "bbbbb",
                "aaaaaaaaa", "bbbbb",
                "aaaaaaaaaa", "bbbbb"
        });

        assertEquals(result,expectedOutput);

    }

}