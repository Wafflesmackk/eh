import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;

public class Adult extends Guest {
    public boolean IsAdult(){
        return true;
    }
}
