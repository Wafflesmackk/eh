public class Guest {
    protected String name;
    protected int age;

    public String getName(){
        return this.name;
    }

    public int getAge(){
        return this.age;
    }

    public boolean IsAdult(){
        return false;
    }
}
