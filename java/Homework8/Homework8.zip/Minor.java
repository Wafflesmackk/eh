public class Minor extends Guest {
    public boolean IsAdult(){
        return false;
    }
    
}
