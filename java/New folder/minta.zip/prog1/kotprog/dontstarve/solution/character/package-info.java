/**
 * A karakterekkel, annak cselekvésével kapcsolatos osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.character;
