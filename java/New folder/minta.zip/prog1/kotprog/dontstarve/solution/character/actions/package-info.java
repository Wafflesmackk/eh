/**
 * A karakterek egy-egy akciójának leírására szolgáló osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.character.actions;
