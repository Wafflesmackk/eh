package person;
public enum Gender {Male,Female};