public class Main {
    public static void main(String[] args) {
        CharCount testCh = new CharCount();
        String testStr = "HelloWorld";
        testCh.countChars(testStr);
            System.out.println(testCh.getData());
    }
}
