import javax.swing.text.rtf.RTFEditorKit;

public class MathUtils {
    public static int Increment(int num){
        int max = Integer.MAX_VALUE;
        if(num == max)
        {
            return num;
        }
        else{
            num++;
            return num;
        }

    }

}
