﻿A mappa tartalma:
- a „peldak” mappában találhatók a futtatáshoz előkészített példák, már kész struktogramok
- a „bin” mappában találhatók az alkalmazás telepítéséhez szükséges mappa és fájlok
- a „dokumentacio.pdf” fájlban található a program dokumentációja

A program csak arról a helyről indul, ahonnan telepítik. Azaz, ha a telepítő médiától 
(pl. CD-től) függetlenül szeretnénk használni, a telepítés előtt célszerű felmásolni a 
„bin” mappa tartalmát a merevlemezre, a kívánt helyre.

A telepítéshez a „bin” mappában található setup.exe fájlt kell elindítani. 
Ezután a program magától elindul.

A későbbiekben az alkalmazás elindítható 
mind a setup.exe, mind a Structogram.application 
fájlok futtatásával. 

Ha a számítógépen Avast vírusirtó van, 
akkor azt ki kell kapcsolni a telepítés, illetve az alkalmazás futtatása előtt.
