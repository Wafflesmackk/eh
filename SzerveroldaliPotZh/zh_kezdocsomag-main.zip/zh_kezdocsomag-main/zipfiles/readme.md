# Becsomagolt feladatok

Az `npm run zip` parancs kiadása után ebben a mappában találod meg a becsomagolt feladatokat, amiket be tudsz adni Canvasen.
